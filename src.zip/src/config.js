/**
 * Created by XTER on 2015/11/19.
 */

var GC = GC || {};
GC.winSize = null;
GC.w = 0;
GC.h = 0;
GC.w_mid = 0;
GC.h_mid = 0;

GC.transTime = 0.5;
GC.StagePageCount = 5;
GC.StageItemRow = 2;
GC.StageItemCol = 4;

GC.DIR_HORIZONTAL = 0;
GC.DIR_VERTICAL = 1;

GC.StarNum = 3;

GC.MapWidth= 32;
GC.MapHeight = 18;